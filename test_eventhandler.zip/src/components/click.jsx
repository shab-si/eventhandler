import React, {Component} from 'react'

export default class Click extends Component {
    constructor(props){
        super(props);  // yani inke propshaye constructor valed yani component ham ejra beshand

        // meghdar gozari avalyeh state
        this.state = {
            clickCount: 0
        } 
    }

    render()
    {
        return (
            <div>
                <p>Click Count Is: {this.state.clickCount}</p>
                <button id="button1" onClick={this.Button1Click.bind(this)}>Click Me</button>

                <br></br>

                <button id = "button2" onClick={this.Button2Click.bind(this)}>Click Me</button>
            </div>
        )
    }
    
    Button1Click(event){
     /*   console.log(event.altKey);
        event.persist();
        setTimeout(function () {
            console.log(event.altKey);
         }, 500);
    */

        this.setState((state) => {
            return {
                clickCount : this.state.clickCount + 1 
              }
         })
    }

    ///////////////////////
    Button2Click(event){
        alert("ok");
        
    }
}