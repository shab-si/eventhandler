import React from 'react';
import Clock from './components/clock';
import Click from './components/click'

export default function App() {
  return (
    <Click />
  )
}